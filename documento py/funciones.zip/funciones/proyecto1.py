def diHola ():
    print("Hello!")
    
diHola()