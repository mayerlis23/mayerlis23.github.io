#Calculadora

#funciones
def suma():
    sum=a+b
    print("La suma es: ", sum)

def resta():
    res=a-b
    print("La resta es: ", res)

def multiplicacion():
    mul=a*b
    print("La multiplicacion es: ", mul)

def divicion():
    div=a/b
    print("La divicion es: ", div)

#Algoritmo para sumar dos nuemeros
print("---------CALCULADORA------------")
a=int(input("Dijite el 1er numero: "))
b=int(input("Dijite el 2do numero: "))

#llamamos las funciones
suma()
resta()
multiplicacion()
divicion()