#Diseñe una App con una funcion que calcule el area del circulo y esta sea llamada por algoritmo

#Funcion
def circulo():
    area=(radio*radio)*3.14
    print("El area del circulo es: ", area)

#Algoritmo
radio=float(input("Dijite el radio: "))

#Lamamos a la funcion
circulo()