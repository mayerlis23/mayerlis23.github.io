def suma():
    sum=a+b
    print("La suma es: ", sum)

#App para sumar dos numeros
a=int(input("Dijite el 1er numero: "))
b=int(input("Dijite el 2do numero: "))

suma() #Llamando la funcion suma(resultado)