#Diseñe una App que cacule el area del rectangulo y 
#luego sea llamada por algoritmo

#Funcion
def rectangulo():
    area=base*altura
    print("el area del rectangulo es: ",area)

#Algoritmo
base=float(input("Dijite la Base: "))
altura=float(input("Dijite la Altura: "))

#Lamamos a la funcion
rectangulo()





