#App que convierta de horas a minutos 

#Funcion
def convertir ():
    minutos=horas*60
    print(horas,"horas son:", minutos, "minutos")


#Algoritmo que convierte de hora a minutos
print("------------convertidor-----------------")
horas=int(input("Dijite las horas que desea convertir: "))

#Lamamos a la funcion
convertir()


