""" Evaluar la edad ingresada
0>= y <2, eres un Baby
2>= y <12, eres un niño(a)
12>= y <=17, eres un adolescente
18>= y <40, eres un adulto joven
40>= y <60, eres un adulto maduro
>=60, eres un adulto mayor
"""
edad=int(input("Ingrese la edad:  "))
if edad >=0 and edad<2:
    print("Eres un Baby")
elif edad >=2 and edad<12:
    print("Eres un niño(a)")
elif edad>=12 and edad<=17:
    print("Eres un adolescente")
elif edad>=18 and edad<40:
    print("eres un adulto joven")
elif edad>=40 and edad<60:
    print("eres un adulto maduro")
elif edad>=60:
    print("eres un adulto mayor")
else:
    print("Esto no es una edad... por favor verifique")