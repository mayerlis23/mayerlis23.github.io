#algoritmo para un almacen de zapatos que tiene una promocion de descuento para vender al mayor
#esta dependera del numero de zapatos que se compren
#el precio de cada zapato debera ser ingresado por pantalla
cantidad=int(input("Escriba la cantidad de zapatos a comprar: "))
precio=float(input("Escriba el presio de los zapatos: "))

total=precio*cantidad

if cantidad<10:
    print("Descuento: no valido")
    print("Total:",total                                     )
elif cantidad>=10 and cantidad<20:
    d=total*0.10
    t=total-d
    print("Recibiste un descuento del 10%")
    print("Descuento:",d)
    print("Total",t)
elif cantidad>=20 and cantidad<30:
    d=total*0.20
    t=total-d
    print("Recibiste un descuento del 20%")
    print("Descuento:",d)
    print("total:",t)
elif cantidad>=30:
    d=total*0.40
    t=total-d
    print("Resibiste un descuento del 40%")
    print("Descuento:",d)
    print("total:",t)