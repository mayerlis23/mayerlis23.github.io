#Evaluar la Presion arterial 
presion=float(input("Dijite su presion arterial: "))
if presion<90:
    print("baja")
elif presion<=120:
    print("normal")
elif presion>120 and presion<139:
    print("Hipertension")
elif presion>=140 and presion<159:
    print("Alta-hipertension fase 1")
elif presion>=160:
    print("Alta-hipertension fase 2")
else:
    print("Error")