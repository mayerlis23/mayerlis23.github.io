"""algoritmo que al ingresar el peso y la estatura defina si esta
es una persoa de bajo peso
es una persona con peso normal
es una persona con sobrepeso
es una persona con obesidad 1
es una persona con obesidad 2
es una persona con obesidad 3
es una persona con obesidad 4
"""

peso=float(input("Ingrese su peso en (kg): "))
estatura=float(input("Ingrese su estatura en (cm): "))
resultado=peso/(estatura*estatura)
if resultado<18.5:
    print("es una persona con bajo peso")
elif resultado<18.5 and resultado<24.9:
    print("es una persona con peso normal")
elif resultado<25 and resultado<29.9:
    print("es una persona con sobrepeso")
elif resultado<30 and resultado<34.9:
    print("es una persona con obesidad 1")
elif resultado<35 and resultado<39.9:
    print("es una persona con obesidad 2")
elif resultado<40 and resultado<49.9:
    print("es una persona con obesidad 3")
elif resultado>50:
    print("es una persona con obesidad 4")
else:
    print("Error")