#algoritmo que ingrese el valor de un producto;
#Si valor del producto es mayor igual a 50.000
#entonces obtendrá el 5% DE DESCUENTO, sino,  no hay descuento.
valor_producto=float(input("Ingrese el valor de un producto: "))
if valor_producto>=50000:
    descuento=valor_producto*0.05
    total=valor_producto-descuento
    print("subtotal: ", valor_producto)
    print("descuento: ", descuento)
    print("total de compra: ", total)

else: 
    descuento=valor_producto*0.0
    total=valor_producto-descuento
    print("subtotal: ", valor_producto)
    print("descuento: ", descuento)
    print("total de compra: ", total)
    