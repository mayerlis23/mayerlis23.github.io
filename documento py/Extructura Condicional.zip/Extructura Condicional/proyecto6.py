#algoritmo que ingrese una nota; Si la nota es mayor igual a 3
#entonces es APROBADO, sino, REPROBADO.
nota=float(input("Ingrese la nota"))
if nota>=3:
    print("Aprobado")
else:
    print("Reprobado")
