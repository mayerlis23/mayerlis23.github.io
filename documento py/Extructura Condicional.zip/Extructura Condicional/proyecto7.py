#algoritmo que
#ingrese un número entero del 1 al 5 y diga si es PRIMO o NO ES PRIMO.
numero=int(input("Ingrese un numero entero del 1 al 5: "))
if numero//4:
    print("este numero es primo")
else:
    print("este numero no es primo")
