#el usuario ingrese el sueldo y el cargo, Si el empleado es CIRUJANO,
#entonces, obtendrá un PREMIO del 50% de su sueldo  y en caso
#contrario el premio sera de 10%
sueldo=float(input("Ingrese el sueldo: "))
cargo=(input("Ingrese el cargo: "))
if cargo=="cirujano":
    premio=sueldo*0.5
    print("El empleado obtuvo un premio del 50%  : " , premio)
else:
    premio=sueldo*0.1
    print("El empleado obtuvo un premio del 10%  :" ,premio)

