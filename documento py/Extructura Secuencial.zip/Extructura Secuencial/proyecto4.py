#algoritmo que al ingresar un monto de dinero (En dólares) Lo convierta a pesos colombianos

dolar=int(input("Cuanto dolar deseea cambiar:"))
convertir=dolar*4.454

print("la cantidad de peso que equivale es:", convertir, "pesos colombianos")