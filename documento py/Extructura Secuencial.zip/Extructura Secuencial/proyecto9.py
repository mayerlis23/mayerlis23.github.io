#Algoritmo que permite multiplicar dos numeros

a=int(input("Dijite el primer numero:"))
b=int(input("Dijite el segundo numero:"))
c=a*b
print("la multiplicacion de ",a, "+" ,b, "es: ",c)