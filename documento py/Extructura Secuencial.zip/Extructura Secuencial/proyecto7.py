#algoritmo que le pregunte al usuario su nombre y luego lo salude
a=input("Escriba su nombre:")

print("hola", a)