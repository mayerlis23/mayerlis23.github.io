"""
creado por. Mayerlis Cardenas
Algoritmo que al ingresar dos numeros los sume
"""
a=int(input("Dijite el primer numero:"))
b=int(input("dijite el segundo numero:"))
c=a+b
print("la suma de",a, "+" ,b," es: ", c)
