#Algoritmo que brinda el 15% de descuento

a=int(input("Dijite el precio del producto comprado:"))

b=(15*a)/100
print("el descuento es de: ",b)