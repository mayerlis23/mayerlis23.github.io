#Algoritmo que calcula el area del circulo
a=float(input("escriba el radio del circulo:"))

b=3.14*(a**2)
print("El area del circulo es: ",b)