#algoritmo que calcule el área de un rectángulo

base=float(input("Digite el base:"))
altura=float(input("Digite la altura:"))

area=base*altura
print("el area del rectangulo es:" ,area)

