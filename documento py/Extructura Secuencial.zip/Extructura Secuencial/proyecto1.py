#Algoritmo que imprima un Hola Mundo!

print("Hola Mundo!")