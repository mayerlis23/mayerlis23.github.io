# algoritmo que al ingresar dos números enteros me calcule la suma, la resta, la multiplicación, Y la división

n1=int(input("Digite el primer numero:"))
n2=int(input("Digite el segundo numero:"))

suma=n1+n2
print("Resultado de la suma es:" ,suma)
resta=n1-n2
print("Resultado de la resta es:" ,resta)
multiplicacion=n1*n2
print("Resultado de la multiplicacion es:" ,multiplicacion)
divicion=n1/n2
print(" Resultado de la divicion es:" ,divicion)
