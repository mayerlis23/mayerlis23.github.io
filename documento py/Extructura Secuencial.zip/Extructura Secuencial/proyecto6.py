#algoritmo que calcule el perímetro de un rectángulo

lado1=float(input("dijite el primer lado"))
lado2=float(input("dijite el primer lado"))
lado3=float(input("dijite el primer lado"))
lado4=float(input("dijite el primer lado"))

suma=lado1+lado2+lado3+lado4
print("el perimetro es", suma)