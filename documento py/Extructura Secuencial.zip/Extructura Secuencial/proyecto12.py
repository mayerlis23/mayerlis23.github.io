#algoritmo que permita ingresar el nombre, la edad y peso de una persona y posteriormente imprimirla de forma concatenada.

nombre=(input("Dijite el nombre"))
edad=(input("Dijite la edad"))
peso=(input("Dijite el peso"))

print("El nombre es:" ,nombre,  "la edad es:" ,edad, " el peso es: " ,edad)