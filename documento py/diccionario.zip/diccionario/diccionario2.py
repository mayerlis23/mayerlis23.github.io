#Disñe un diccionario con las marcas de vehiculos y los modelos debe tener un tamaño minimo de 10 elementos
vehiculos={"BMW":" Serie 2 Active Tourer","Isuzu":"D-Max","Jaguar":"E-PACE","Lexus":"CT","Morgan":"plus 4","Nissan":"Versa","Caterham":"7 CSR 175","Smart":"forfour","Subaru":"Forester","Volvo":"XC90"}
print(vehiculos["Isuzu"])
print(vehiculos["BMW"])
print(vehiculos["Jaguar"])
print(vehiculos["Lexus"])
print(vehiculos["Morgan"])
print(vehiculos["Nissan"])
print(vehiculos["Caterham"])
print(vehiculos["Smart"])
print(vehiculos["Subaru"])
print(vehiculos["Volvo"])
