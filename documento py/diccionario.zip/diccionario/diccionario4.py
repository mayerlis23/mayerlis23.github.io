#Diccionario de personas
personas={"John Peres":{"Id":1129184402,"Edad":17,"Sexo":"M","Cel":3215693744,"Correo":"io@gmail.com"},"Fabian Vergara":{"Id":1129598634,"Edad":25,"Sexo":"M","Cel":3215264744,"Correo":"favian@gmail.com"},"Casandra Salgado":{"Id":1129236802,"Edad":19,"Sexo":"F","Cel":3212369874,"Correo":"casansal@gmail.com"},"Luz Borga":{"Id":1159884402,"Edad":21,"Sexo":"F","Cel":3215528964,"Correo":"luz@gmail.com"},"Andres Carcamo":{"Id":1185236402,"Edad":26,"Sexo":"M","Cel":321983265,"Correo":"andres@gmail.com"}}
print(personas["Casandra Salgado"])
print(personas["John Peres"])
print(personas["Andres Carcamo"])
print(personas["Luz Borga"])
print(personas["Fabian Vergara"])


