#diccionario de veterinaria
perros={"Tom":["Nombre: Tom","Raza: chihuahua","Tamaño: 15.2-22.9","color: castaño","Fecha de nacimiento: 25-05-2009","Dueño(a): Pedro","Telefono: 321562987"],"zeus":["Nombre: zeus","Raza: Pastor Aleman","Tamaño: 55-60 cm","color: Marron oscuro","Fecha de nacimiento: 18-02-2020","Dueño(a): Matilda","Telefono: 321236987"],"Pulga":["Nombre: Pulga","Raza: yorkshire terrier","Tamaño: 15 y 17 cm","color: castaño","Fecha de nacimiento: 10-08-2018","Dueño(a): Roberto","Telefono: 310529987"],"lucy":["Nombre: lucy","Raza: Bichon Maltes","Tamaño: 21–25 cm","color: blanco","Fecha de nacimiento: 20-11-2018","Dueño(a): Marta","Telefono: 310529987"],"Blu":["Nombre: Blu","Raza: beagle","Tamaño: 36–41 cm","color: castaño y blanco","Fecha de nacimiento: 12-03-2019","Dueño(a): Samuel","Telefono: 352369787"]}
print(perros["Tom"])
print(perros["zeus"])
print(perros["Pulga"])
print(perros["lucy"])
print(perros["Blu"])