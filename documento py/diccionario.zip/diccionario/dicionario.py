#Diccionario: Busqueda por clave
dict={"Sucre":"Sincelejo","Cordoba":"Monteria","Bolivar":"Cartagena","Atlantico":"Barranquilla","Cundinamarca":"Bogota,","Guainía":"Inírida","Guaviare":"San José del Guaviare","Huila":"Neiva","Caquetá":"Florencia"}
print(dict["Sucre"])
print(dict["Cordoba"])
print(dict["Bolivar"])
print(dict["Atlantico"])
print(dict["Cundinamarca"])
print(dict["Guainía"])
print(dict["Guaviare"])
print(dict["Huila"])
print(dict["Caquetá"])
