#Diccionario de frutas
frutas={"dulces":["piña","manzana","pera","sandia"],"citricas":["toronja","limon","naranja","pomelo"],"secos":["avellanas","nuez","castañas","Pistacho"],"neutras":["aguacate","maní","almendra","cacahuete"]}
print(frutas["dulces"])
print(frutas["citricas"])
print(frutas["secos"])
print(frutas["neutras"])