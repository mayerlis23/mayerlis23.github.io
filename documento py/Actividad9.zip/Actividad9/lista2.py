#listas de plantas medicinales con 9 posiciones
planta=["Aloe vera.", "Alcachofa.", "Eucalipto.", "Eucalipto.", "Manzanilla.", "Lavanda.", "Ginkgo.", "Amapola.", "Tomillo.", ]
#Eliminar un elemento del vector
planta.pop(5)
print(planta)
#Añadimos un elemento a la lista
planta.append("Hipérico.")
#Recorremos la lista
for x in planta:
    print(x)
#Definimos la longitud de la lista
    longitud=len(planta)
print("El tamaño o longitud es: ", longitud)