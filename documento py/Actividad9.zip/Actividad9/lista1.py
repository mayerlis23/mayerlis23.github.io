#lista de libros con 7 posiciones
libros=["El Alquimista.", "El Principito.", "El retrato de Dorian Grey.", "Los Miserables.", "Cien años de Soledad.", "La Divina Comedia.", "Atravez de la ventana.", "Un mundo feliz."]
#Eliminar un elemento del vector
libros.pop(4)
print(libros)
#Añadimos un elemento a la lista
libros.append("la purga.")
#Recorremos la lista
for x in libros:
    print(x)
#Definimos la longitud de la lista
longitud=len(libros)
print("El tamaño o longitud es: ", longitud)
 