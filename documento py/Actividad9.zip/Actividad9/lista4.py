#listas de colores con 8 posiciones
colores=["Amarillo.","Azul.","Rojo.","Rosado.","Verde.","Marron.","Blanco.","Negro.",]
#Eliminar un elemento del vector
colores.pop(3)
print(colores)
#Añadimos un elemento a la lista
colores.append("Rosado.")
#Recorremos la lista
for x in colores:
    print(x)
#Definimos la longitud de la lista
    longitud=len(colores)
print("El tamaño o longitud es: ", longitud)