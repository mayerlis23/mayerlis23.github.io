#listas de lenguaje de programacion con 5 posiciones
lenguaje=["Python.", "Psein.", "JavaScript.", "CSS.", "Java.",]
#Eliminar un elemento del vector
lenguaje.pop(2)
print(lenguaje)
#Añadimos un elemento a la lista
lenguaje.append("C++.")
#Recorremos la lista
for x in lenguaje:
    print(x)
#Definimos la longitud de la lista
    longitud=len(lenguaje)
print("El tamaño o longitud es: ", longitud)