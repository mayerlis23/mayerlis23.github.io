#Diseñe una App con una funcion que calcule el area del circulo y esta sea llmada por algoritmo
#CON PARAMETRO

#Funcion
def circulo(radio):
    area=(radio*radio)*3.14
    print("El area del circulo es: ", area)

#Algoritmo
radio=float(input("Dijite el radio: "))

#Lamamos a la funcion
circulo(radio)