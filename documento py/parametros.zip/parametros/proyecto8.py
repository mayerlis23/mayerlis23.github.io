#App que convierta de horas a minutos con parametros

#Funcion
def convertir (horas):
    minutos=horas*60
    print(horas,"horas son:", minutos, "minutos")


#Algoritmo que convierte de hora a minutos
print("------------convertidor-----------------")
horas=int(input("Dijite las horas que desea convertir: "))

#Lamamos a la funcion
convertir(horas)

