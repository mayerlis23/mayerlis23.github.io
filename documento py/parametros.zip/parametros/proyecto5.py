#FUNCIONES CON PARAMETROS
"""Escribir una funcion a la que se le pase una cadena 
<nombre> y muestre por pantalla el saludo ¡Hola <nombre>!"""

#Funcion de saludo
def saludo(name):
    print("Hola ",name)

#App que ingrese un nombre y lo muestre como saludo
nombre=input("¿Cual es tu nombre? ")

saludo(nombre) #Llamando a la funcion