#Diseñe una App con una funcion que calcule el area del triangulo y esta sea llmada por algoritmo
#CON PARAMETRO

#Funcion
def triangulo(base,altura):
    area=(base*altura)/2
    print("El area del triangulo es: ", area)

#Algoritmo
base=float(input("Dijite la base del triangulo: "))
altura=float(input("Dijite la base del triangulo: "))

#Lamamos a la funcion
triangulo(base,altura)