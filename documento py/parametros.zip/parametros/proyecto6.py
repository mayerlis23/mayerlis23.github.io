#FUNCION CON PARAMETROS

#funcion suma
def suma(a,b):
    sum=a+b
    print("la suma es: ", sum)

#App que ingresa dos enteros y los suma 
a=int(input("Dijite el 1er numero: "))
b=int(input("Dijite el 2do numero: "))

suma(a,b)