#Diseñe una App con una funcion que calcule el area del cuadrado y esta sea llmada por algoritmo
#CON PARAMETRO

#Funcion
def cuadrado(lado):
    area=lado*lado
    print("El area del cuadrado es: ", area)

#Algoritmo
lado=float(input("Dijite el lado del cuadrado: "))

#Lamamos a la funcion
cuadrado(lado)