#Calculadora con parametros

#funciones
def suma(a,b):
    sum=a+b
    print("La suma es: ", sum)

def resta(a,b):
    res=a-b
    print("La resta es: ", res)

def multiplicacion(a,b):
    mul=a*b
    print("La multiplicacion es: ", mul)

def divicion(a,b):
    div=a/b
    print("La divicion es: ", div)

#Algoritmo para sumar dos nuemeros
print("---------CALCULADORA------------")
a=int(input("Dijite el 1er numero: "))
b=int(input("Dijite el 2do numero: "))

#llamamos las funciones
suma(a,b)
resta(a,b)
multiplicacion(a,b)
divicion(a,b)