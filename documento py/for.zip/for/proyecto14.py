#for :App que muestre los numeros impares del 1 al 100
for i in range(1,100,2):
    print(i)