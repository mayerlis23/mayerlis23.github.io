# for: App que muestre los numeros pares del 1 al 100
for i in range(2,100,2):
    print(i)