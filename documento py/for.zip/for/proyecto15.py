# for: App que muestre la multiplicacion de los numeros del 1 al 100
n=1
for i in range(1,100,1):
    n=n*i
print(n)