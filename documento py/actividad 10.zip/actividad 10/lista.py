"""Diseñar una App que resiva una lista vacia; dicha lista el usuario define su tamaño y los valores de cada elmento
la App debe mostrar
-los valores de la lista actualizada"""

#Creamos listas (vacias al comienzo)
nombres=[]
#definimos un tamaño para las listas
#lo puedes cambiar si quieres
tamaño=int(input("Tamaño de lista? :"))
#Recorremos la lista hasta el tamaño definido
for i in range(tamaño):
    print("Ingrese los datos del aprendiz ", i + 1)
    nombre=input("Nombre del aprendiz: ")
    nombres.append(nombre)
print("los aprendices son :")
#Ahora mostramos las listas
for i in range(tamaño):
    print("-----------------------------------")
    print("Nombre:", nombres[i])