#Diseñe una App  que permita al usuario ingresar fruta y
#el precio unitario, la cantidad y  lo almacene en un diccionario llamado factura.
#despues debe mostrar un mensaje concatenado donde aparece el nombre de la fruta su valor
#la cantidad y el total
fruta=input("Ingresar nombre de la fruta: ")
precioU=int(input("Ingresar el precio unitario: "))
cantidad=int(input("Ingresar la cantidad: "))

factura={"fruta":fruta,"precioU": precioU,"cantidad":cantidad}
total=precioU*cantidad

print("La", factura["fruta"], "tiene un costo de", factura["precioU"], "con una cantidad de", factura["cantidad"])
print("Su total seria: ", total)
