#Diseñe una App que permita almacenar la inforrmacion de los clientes de una empresa.
#los clientes se guardaran en un diccionario llamado clientes. los datosdeben ser
#ingresados por el usuario, identificacion del cliente, nombre, direccion, telefono, correo
#y empresa. la App debe preguntar al usuario por una opcion del menu primero: añadir cliente
#segundo: mostrar cliente, tercero: eliminar cliente, cuarto: salir o finalizar


cliente={}
op=""
while op !=4:
    if op ==1:
        identificacion=input("Dijite su Identificacion: ")
        nombre=input("Dijite su nombre: ")
        direccion=input("Dijite su dirrecion: ")
        telefono=input("Dijite su telefono: ")
        correo=input("Dijite su correo: ")
        empresa=input("Dijite el nombre de su empresa: ")
        cliente={"identificacion":identificacion,"nombre":nombre,"direccion":direccion,"telefono":telefono,"correo":correo,"empresa":empresa} 

    if op ==2: 
        print("Informacion del Cliente")
        print("------------------------")
        print("identificacion: " , cliente["identificacion"])
        print("nombre: " , cliente["nombre"])
        print("dirrecion: " , cliente["direccion"])
        print("telefono: " , cliente["telefono"])
        print("correo: " , cliente["correo"])
        print("empresa: " , cliente["empresa"])

    if op ==3:
        del cliente["identificacion"]
    if op ==4:
        exit()
    print("----MENU----")
    print("1- AÑADIR CLIENTE")
    print("2- MOSTRAR CLIENTE")
    print("3- ELIMINAR CLIENTE")
    print("4- SALIR")
    op=int(input("Dijite la opcion seleccionada: "))