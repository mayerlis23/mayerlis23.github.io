"""Diseñe una App que permita al usuario nombre, edad, direccion y telefono;
 estos datos se deben almacenar en un diccionario llamado persona.
estos datos se deben mostrar por pantalla de forma concatenada. 
ejemplo: Juan tiene 17 años, vive en la calle 8 #27-8a y su numero de telfono es 1234567
"""
nombre=input("Dijite su nombre: ")
edad=input("Dijite su edad: ")
direccion=input("Dijite su Direccion: ")
telefono=input("Dijite su Telefono: ")

persona={"nombre":nombre,"edad":edad,"direccion":direccion,"telefono":telefono}

print(persona["nombre"] , "tiene: ", persona["edad"], "años",", vive en: ", persona["direccion"], "y su numero de telefono es: ", persona["telefono"])