#while: App que muestre los numeros del 100 al 1
i=100
while i>=1:
    print(i)
    i+=-1