#while: App que muestr los numeros pares del 1 al 100

i=1
while i<=100:
    print(i)
    i=i*2